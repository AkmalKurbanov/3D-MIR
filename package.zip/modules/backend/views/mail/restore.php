subject = "Password Reset"
layout = "system"
description = "Reset an admin password"
==
Hello {{ name }}

Somebody has requested a password reset for your account, if this was not you, please ignore this email.

You can use the following link to restore your password:

{% partial 'button' url=link type='positive' body %}
Restore password
{% endpartial %}
