subject = "Welcome to {{ appName | raw }}"
layout = "system"
description = "Invite new admin to the site"
==
Hi {{ name }}

A user account has been created for you on **{{ appName }}**.

{% partial 'panel' body %}
- Login: `{{ login ?: 'sample' }}`
- Password: `{{ (password ?: '********') | raw }}`
{% endpartial %}

You can use the following link to sign in:

{% partial 'button' url=link body %}
    Sign in to admin area
{% endpartial %}

After signing in you should change your password by clicking your name on the top right corner of the administration area.
