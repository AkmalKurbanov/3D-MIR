# Winter CMS - Backend Module

This repository is a read-only sub-split of the Winter CMS `Backend` module for use in Composer. Please note that we do not accept any pull requests to this repository.

If you wish to make changes to this module, please submit them to the [main repository](https://github.com/wintercms/winter).
