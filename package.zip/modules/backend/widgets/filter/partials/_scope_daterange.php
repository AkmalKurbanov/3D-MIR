<!-- Date Range scope -->
<a
    class="filter-scope-date filter-has-popover range <?= isset($after) || isset($before) ? 'active' : '' ?>"
    href="javascript:;"
    data-scope-name="<?= $scope->scopeName ?>"
    data-scope-data="<?= e(json_encode([
        'dates' =>  [isset($after) ? $after : null, isset($before) ? $before : null],
        'minDate' => $scope->minDate,
        'maxDate' => $scope->maxDate,
        'firstDay' => $scope->firstDay,
        'yearRange' => $scope->yearRange,
    ])) ?>"
    <?= $scope->ignoreTimezone ? 'data-ignore-timezone' : ''; ?>
>
    <span class="filter-label"><?= e(trans($scope->label)) ?>:</span>
    <span class="filter-setting"><?= isset($afterStr) && isset($beforeStr) ? ($afterStr . ' → ' . $beforeStr) : e(trans('backend::lang.filter.date_all')) ?></span>
</a>
