<!-- Number scope -->
<a
    class="filter-scope-number filter-has-popover <?= isset($number) ? 'active' : '' ?>"
    href="javascript:;"
    data-scope-name="<?= $scope->scopeName ?>"
    data-scope-data="<?= e(json_encode([
        'number' => isset($number) ? $number : null,
        'step' => isset($step) ? $step : null,
        'minValue' => isset($minValue) ? $minValue : null,
        'maxValue' => isset($maxValue) ? $maxValue : null,
    ]))
    ?>">
    <span class="filter-label"><?= e(trans($scope->label)) ?>:</span>
    <span class="filter-setting"><?= isset($number) ? $number : e(trans('backend::lang.filter.number_all')) ?></span>
</a>
