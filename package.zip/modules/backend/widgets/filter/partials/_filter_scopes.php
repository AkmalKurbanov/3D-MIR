<?php foreach ($scopes as $scope): ?>
    <?= $this->renderScopeElement($scope) ?>
<?php endforeach ?>
