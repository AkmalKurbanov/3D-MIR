<!-- Date scope -->
<a
    class="filter-scope-date filter-has-popover <?= isset($date) ? 'active' : '' ?>"
    href="javascript:;"
    data-scope-name="<?= $scope->scopeName ?>"
    data-scope-data="<?= e(json_encode([
        'date' => isset($date) ? $date : null,
        'minDate' => $scope->minDate,
        'maxDate' => $scope->maxDate,
        'firstDay' => $scope->firstDay,
        'yearRange' => $scope->yearRange,
    ])) ?>"
    <?= $scope->ignoreTimezone ? 'data-ignore-timezone' : ''; ?>
>
    <span class="filter-label"><?= e(trans($scope->label)) ?>:</span>
    <span class="filter-setting"><?= isset($dateStr) ? $dateStr : e(trans('backend::lang.filter.date_all')) ?></span>
</a>
