<!-- Switch scope -->
<div
    class="filter-scope checkbox custom-checkbox is-indeterminate"
    data-scope-name="<?= $scope->scopeName ?>">
    <input type="checkbox" id="<?= $scope->getId() ?>" data-checked="<?= $scope->value ?: '0' ?>" />
    <label for="<?= $scope->getId() ?>"><?= e(trans($scope->label)) ?></label>
</div>
