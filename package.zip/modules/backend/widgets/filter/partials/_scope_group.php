<!-- Group scope -->
<a
    class="filter-scope <?= $scope->value ? 'active' : '' ?>"
    href="javascript:;"
    data-scope-name="<?= $scope->scopeName ?>"
    <?php if ($depends = $this->getScopeDepends($scope)): ?>
        data-scope-depends="<?= $depends ?>"
    <?php endif ?>
>
    <span class="filter-label"><?= e(trans($scope->label)) ?>:</span>
    <span class="filter-setting"><?= $scope->value ? count($scope->value) : e(trans('backend::lang.filter.all')) ?></span>
</a>
