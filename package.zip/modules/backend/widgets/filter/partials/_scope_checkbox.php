<!-- Checkbox scope -->
<div
    class="filter-scope checkbox custom-checkbox"
    data-scope-name="<?= $scope->scopeName ?>">
    <input type="checkbox" id="<?= $scope->getId() ?>" <?= $scope->value ? 'checked' : '' ?> />
    <label for="<?= $scope->getId() ?>"><?= e(trans($scope->label)) ?></label>
</div>
