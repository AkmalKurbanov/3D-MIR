<div class="filter-scope text loading-indicator-container size-input-text">
    <label class="filter-label">
        <?= e(trans($scope->label)) ?>:
        <input type="text"
               name="options[value][<?= $scope->scopeName ?>]"
               data-request="<?= $this->getEventHandler('onFilterUpdate') ?>"
               data-request-data="'scopeName':'<?= $scope->scopeName ?>'"
               data-track-input
               data-load-indicator
               data-load-indicator-opaque
               size="<?= $size ?>"
               value="<?= isset($value) ? e($value):''; ?>"
               class="form-control"/>
    </label>
</div>
