<?php foreach ($fields as $field): ?>
    <?= $this->makePartial('field-container', ['field' => $field]) ?>
<?php endforeach ?>
