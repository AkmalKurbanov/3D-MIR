<?php
$type = $tabs->section;

$containerCss = 'layout-row min-size';

if ($tabs->stretch) {
    $containerCss = 'layout-row';
}
?>
<!-- <?= ucfirst($type) ?> Tabs -->
<div class="<?= $containerCss ?>">
    <?php if ($tabs->suppressTabs): ?>

        <div
            id="<?= $this->getId($type.'Tabs') ?>"
            class="form-tabless-fields <?= $tabs->cssClass ?>">
            <?= $this->makePartial('form_fields', ['fields' => $tabs]) ?>
        </div>

    <?php else: ?>

        <div
            id="<?= $this->getId($type.'Tabs') ?>"
            class="control-tabs <?= $type ?>-tabs layout <?= $tabs->cssClass ?>"
            data-control="tab">
            <?= $this->makePartial('form_tabs', ['tabs' => $tabs]) ?>
        </div>

    <?php endif ?>
</div>
