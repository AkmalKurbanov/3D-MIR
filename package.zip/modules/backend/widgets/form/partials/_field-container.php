<div
    class="form-group <?= $this->previewMode ? 'form-group-preview' : '' ?> <?= $field->type ?>-field span-<?= $field->span ?> <?= $field->required?'is-required':'' ?> <?= $field->stretch?'layout-relative':'' ?> <?= $field->cssClass ?>"
    <?php if ($depends = $this->getFieldDepends($field)): ?>
        data-field-depends="<?= $depends ?>"
    <?php endif ?>
    data-field-name="<?= $field->fieldName ?>"
    <?= $field->getAttributes('container') ?>
    id="<?= $field->getId('group') ?>"><?=
    /* Must be on the same line for :empty selector */
    trim($this->makePartial('field', ['field' => $field]))
    ?></div>
