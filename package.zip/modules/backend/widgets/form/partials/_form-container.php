<div
    data-control="formwidget"
    data-refresh-handler="<?= $this->getEventHandler('onRefresh') ?>"
    class="form-widget form-elements layout"
    role="form"
    id="<?= $this->getId() ?>">

    <?= $this->makePartial('form') ?>

</div>
