<?php
$fieldOptions = $field->options();
?>
<!-- Balloon selector -->
<div
    data-control="balloon-selector"
    id="<?= $field->getId() ?>"
    class="control-balloon-selector <?= $this->previewMode || $field->disabled ? 'control-disabled' : '' ?>"
    <?= $field->getAttributes() ?>>
    <ul>
        <?php foreach ($fieldOptions as $value => $text): ?>
            <li data-value="<?= e($value) ?>" class="<?= $field->isSelected($value) ? 'active' : '' ?>"><?= e(trans($text)) ?></li>
        <?php endforeach ?>
    </ul>

    <input
        type="hidden"
        name="<?= $field->getName() ?>"
        id="<?= $field->getId() ?>"
        value="<?= e($field->value) ?>"
        />
</div>
