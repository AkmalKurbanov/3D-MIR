
<?php if ($outsideTabs->hasFields()): ?>
    <?= $this->makePartial('section', ['tabs' => $outsideTabs]) ?>
<?php endif ?>

<?php if ($primaryTabs->hasFields()): ?>
    <?= $this->makePartial('section', ['tabs' => $primaryTabs]) ?>
<?php endif ?>

<?php if ($secondaryTabs->hasFields()): ?>
    <?= $this->makePartial('section', ['tabs' => $secondaryTabs]) ?>
<?php endif ?>