<div class="list-widget list-scrollable-container <?= $cssClasses ?>" id="<?= $this->getId() ?>">
    <?= $this->makePartial('list') ?>
</div>