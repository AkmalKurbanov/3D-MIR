<div class="loading-indicator-container size-small pull-right">
    <div class="control-pagination">
        <?php if ($pageCurrent > 1): ?>
            <a
                href="javascript:;"
                class="page-first"
                data-request="<?= $this->getEventHandler('onPaginate') ?>"
                data-request-data="page: 1"
                data-load-indicator="<?= e(trans('backend::lang.list.loading')) ?>"
                title="<?= e(trans('backend::lang.list.first_page')) ?>"></a>
        <?php else: ?>
            <span
                class="page-first"
                title="<?= e(trans('backend::lang.list.first_page')) ?>"></span>
        <?php endif ?>
        <?php if ($pageCurrent > 1): ?>
            <a
                href="javascript:;"
                class="page-back"
                data-request="<?= $this->getEventHandler('onPaginate') ?>"
                data-request-data="page: <?= $pageCurrent-1 ?>"
                data-load-indicator="<?= e(trans('backend::lang.list.loading')) ?>"
                title="<?= e(trans('backend::lang.list.prev_page')) ?>"></a>
        <?php else: ?>
            <span
                class="page-back"
                title="<?= e(trans('backend::lang.list.prev_page')) ?>"></span>
        <?php endif ?>
        <select
            disabled
            name="page"
            class="form-control input-sm custom-select select-no-search"
            autocomplete="off">
                <option value="<?= $pageCurrent ?>" selected><?= $pageCurrent ?></option>
        </select>
        <?php if ($hasMorePages): ?>
            <a
                href="javascript:;"
                class="page-next"
                data-request-data="page: <?= $pageCurrent+1 ?>"
                data-request="<?= $this->getEventHandler('onPaginate') ?>"
                data-load-indicator="<?= e(trans('backend::lang.list.loading')) ?>"
                title="<?= e(trans('backend::lang.list.next_page')) ?>"></a>
        <?php else: ?>
            <span
                class="page-next"
                title="<?= e(trans('backend::lang.list.next_page')) ?>"></span>
        <?php endif ?>
    </div>
</div>
