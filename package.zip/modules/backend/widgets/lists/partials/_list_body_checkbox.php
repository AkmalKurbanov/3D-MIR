<td class="list-checkbox nolink">
    <div class="checkbox custom-checkbox nolabel">
        <input
            type="checkbox"
            name="checked[]"
            id="<?= $this->getId('checkbox-' . $record->getKey()) ?>"
            value="<?= $record->getKey() ?>"
            autocomplete="off"/>
        <label for="<?= $this->getId('checkbox-' . $record->getKey()) ?>"><?= e(trans('backend::lang.list.check')) ?></label>
    </div>
</td>
