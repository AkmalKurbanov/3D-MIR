<div>
    <?php foreach ($this->formWidget->model->getEditorToolbarPresets() as $name => $preset): ?>
        <button type="button" class="btn btn-default btn-sm"
                data-preset="<?= e($preset) ?>"
                onclick="document.querySelector('#Form-field-EditorSetting-html_toolbar_buttons').value = this.dataset.preset"
        >
            <?= e(trans('backend::lang.editor.toolbar_buttons_presets.' . $name)) ?>
        </button>
    <?php endforeach; ?>
</div>
