<div class="export-behavior">

    <?= $exportFormatFormWidget->render() ?>

    <?php if ($exportOptionsFormWidget): ?>
        <?= $exportOptionsFormWidget->render() ?>
    <?php endif ?>

</div>
