<div data-control="toolbar">
    <a
        href="javascript:;"
        id="showIgnoredColumnsButton"
        class="btn btn-sm btn-secondary wn-icon-eye disabled"
        onclick="$.wn.importBehavior.showIgnoredColumns()">
        <?= e(trans('backend::lang.import_export.show_ignored_columns')) ?>
    </a>
    <a
        href="javascript:;"
        id="autoMatchColumnsButton"
        class="btn btn-sm btn-secondary wn-icon-bullseye"
        onclick="$.wn.importBehavior.autoMatchColumns()">
        <?= e(trans('backend::lang.import_export.auto_match_columns')) ?>
    </a>
</div>
