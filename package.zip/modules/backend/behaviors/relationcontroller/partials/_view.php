<?php if ($relationViewFilterWidget): ?>
    <?= $relationViewFilterWidget->render() ?>
<?php endif ?>

<?= $relationViewWidget->render() ?>
