<a
    data-control="popup"
    data-size="huge"
    data-handler="onRelationButtonLink"
    href="javascript:;"
    class="btn btn-sm btn-secondary wn-icon-link">
    <?= e(trans($text, ['name' => trans($relationLabel)])) ?>
</a>
