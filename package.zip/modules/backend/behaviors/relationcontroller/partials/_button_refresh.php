<button
    class="btn btn-sm btn-secondary wn-icon-arrows-rotate"
    data-request="onRelationButtonRefresh"
    data-stripe-load-indicator>
    <?= e(trans($text)) ?>
</button>
