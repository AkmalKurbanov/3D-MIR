<button
    type="submit"
    class="btn btn-primary">
    <?= e(trans('backend::lang.relation.create')) ?>
</button>
<button
    type="button"
    class="btn btn-default"
    data-dismiss="popup">
    <?= e(trans('backend::lang.relation.cancel')) ?>
</button>
