<?php foreach (Flash::all() as $type => $message): ?>
    <p data-control="flash-message" class="flash-message fade <?= $type ?>" data-interval="5"><?= e($message) ?></p>
<?php endforeach ?>