<footer id="layout-footer">
    <div class="brand">
        <span class="logo"><i class="icon-leaf"></i></span>
        <span class="name"><?= e(trans('system::lang.app.name')) ?></span>
    </div>
    <div class="tagline">
        <p><?= e(trans('system::lang.app.tagline')) ?></p>
    </div>
</footer>