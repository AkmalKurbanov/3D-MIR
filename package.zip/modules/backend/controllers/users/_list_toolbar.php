<div data-control="toolbar">
    <a href="<?= Backend::url('backend/users/create') ?>" class="btn btn-primary wn-icon-plus">
        <?= e(trans('backend::lang.user.new')) ?>
    </a>
    <?php if ($this->user->isSuperUser()): ?>
        <a href="<?= Backend::url('backend/userroles') ?>" class="btn btn-default wn-icon-address-card">
            <?= e(trans('backend::lang.user.role.list_title')) ?>
        </a>
    <?php endif ?>
    <a href="<?= Backend::url('backend/usergroups') ?>" class="btn btn-default wn-icon-group">
        <?= e(trans('backend::lang.user.group.list_title')) ?>
    </a>
    <?php /* @todo
    <div class="btn-group">
        <button
            class="btn btn-default wn-icon-ban-circle"
            disabled="disabled"
            data-trigger-action="enable"
            data-trigger=".control-list input[type=checkbox]"
            data-trigger-condition="checked">Ban</button>
        <button
            class="btn btn-default wn-icon-trash-o"
            disabled="disabled"
            data-trigger-action="enable"
            data-trigger=".control-list input[type=checkbox]"
            data-trigger-condition="checked">Delete</button>
    </div>
    */ ?>
</div>
