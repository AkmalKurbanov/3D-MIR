<?= Block::put('body') ?>
    <?= Form::open(['class'=>'layout', 'onsubmit'=>'return false']) ?>
        <?= $this->widget->manager->render() ?>
    <?= Form::close() ?>
<?= Block::endPut() ?>
